var searchData=
[
  ['nearbysearchwithsearchinfo_3a',['nearbySearchWithSearchInfo:',['../interface_b_m_k_cloud_search.html#abe65e1b2f2b67e1d081c697caae80e4b',1,'BMKCloudSearch']]]
];
