var searchData=
[
  ['latitudedelta',['latitudeDelta',['../struct_b_m_k_coordinate_span.html#a759543f626366ce4fe599b8896f352a2',1,'BMKCoordinateSpan']]],
  ['latitudee6',['latitudeE6',['../struct_b_m_k_geo_point.html#ad6f5b38335cff314e953e9b7eb5c7b39',1,'BMKGeoPoint']]],
  ['longitudedelta',['longitudeDelta',['../struct_b_m_k_coordinate_span.html#ab3bc7d18bbd0fce7c806c51f0e0df447',1,'BMKCoordinateSpan']]],
  ['longitudee6',['longitudeE6',['../struct_b_m_k_geo_point.html#aac3f3dc0ae09785e5b70c319b68d4047',1,'BMKGeoPoint']]]
];
