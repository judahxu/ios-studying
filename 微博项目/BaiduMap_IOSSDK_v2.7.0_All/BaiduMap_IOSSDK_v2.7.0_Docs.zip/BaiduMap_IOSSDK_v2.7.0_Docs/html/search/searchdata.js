var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwxyz",
  1: "b",
  2: "_abcdefgilmnoprstuvwz",
  3: "_chlnoswxy",
  4: "abcdefghiklmnoprstuvwz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "properties"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "函数",
  3: "变量",
  4: "属性"
};

